#!/usr/bin/env python3
import datetime
import json
import os
import time

def main():
    db_path = "data/calculators.json"
    os.makedirs("data", exist_ok=True)
    existing = json.load(open(db_path, encoding="utf-8")) if os.path.exists(db_path) else []

    api_key = os.environ.get("GEMINI_API_KEY", "").strip()
    if api_key:
        from google import genai
        client = genai.Client(api_key=api_key)
        prompt = (
            "Generate 1 new unique US B2B ROI Calculator JSON object with keys: "
            "slug, title, niche (fpa, video, or dev), default_seats (int), default_hours (int), default_rate (int). "
            "Return ONLY valid JSON."
        )
        try:
            resp = client.models.generate_content(model="gemini-2.5-flash", contents=prompt)
            time.sleep(5)  # Strict 12 RPM rate-limit guard (<15 RPM free tier limit)
            raw = resp.text.strip().strip("`").replace("json\n", "")
            new_item = json.loads(raw)
            if isinstance(new_item, dict) and "slug" in new_item:
                existing.append(new_item)
        except Exception as err:
            print("Note:", err)

    with open(db_path, "w", encoding="utf-8") as f:
        json.dump(existing, f, indent=2)

    # Build RSS 2.0 Syndication Feed for Buffer / Pinterest / Medium auto-import
    rss_items = []
    for item in existing[-10:]:
        rss_items.append(
            f"<item><title>{item.get('title')}</title>"
            f"<link>https://your-site.pages.dev/#{item.get('slug')}</link>"
            f"<description>Interactive US B2B Calculator: {item.get('title')}</description></item>"
        )
    rss_xml = (
        "<?xml version='1.0' encoding='UTF-8'?>"
        "<rss version='2.0'><channel>"
        "<title>US B2B AI &amp; FP&amp;A ROI Decision Engine</title>"
        "<link>https://your-site.pages.dev</link>"
        "<description>Automated B2B ROI Calculators &amp; CFO AI Workflows</description>"
        + "".join(rss_items)
        + "</channel></rss>"
    )
    with open("rss.xml", "w", encoding="utf-8") as f:
        f.write(rss_xml)
    print("Updated data/calculators.json and rss.xml successfully.")

if __name__ == "__main__":
    main()
